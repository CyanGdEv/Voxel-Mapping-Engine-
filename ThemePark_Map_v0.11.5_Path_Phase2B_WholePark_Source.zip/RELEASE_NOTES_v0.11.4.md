# ThemePark Map v0.11.4 — Path Phase 2A

## Top-surface path and plaza painting

- Accepted mapped or imagery-derived path polygons can replace grass and other natural top-surface materials.
- Painting replaces only the top terrain block; DTM elevation and subsurface terrain remain unchanged.
- Plaza polygons paint their complete area rather than becoming centre-line strips.
- The world report records total path cells, plaza cells, and unique natural-ground cells replaced.
- Grass, meadow, park, moss, podzol, coarse dirt, and woodland-floor top surfaces are treated as replaceable natural ground.
- Buildings, water, and woody vegetation remain path-discovery exclusion evidence.

## Validation

- 14/14 focused path, appearance, vegetation, and direct-world compatibility tests passed.
- A dedicated regression test verifies that plaza painting does not raise terrain.
