import test from "node:test";
import assert from "node:assert/strict";
import { recoverPathTopology } from "../src/lib/path-topology.mjs";

function mappedPath() {
  return {
    id: "path:main",
    name: "Main path",
    kind: "path",
    subtype: "footway",
    tags: { highway: "footway", surface: "asphalt" },
    localGeometry: { type: "LineString", coordinates: [[5, 40], [35, 40]] },
    geometry: { type: "LineString", coordinates: [[5, 40], [35, 40]] },
    orthophoto: {
      path: {
        status: "accepted",
        colourRgb: [60, 62, 64],
        colour: "#3c3e40",
        material: "asphalt",
        pattern: "solid",
        widthM: 6,
        confidence: 0.92,
        compilationEligible: true
      }
    }
  };
}

function mapFixture() {
  return {
    boundary: {
      localGeometry: { type: "Polygon", coordinates: [[[0, 0], [100, 0], [100, 80], [0, 80], [0, 0]]] }
    },
    features: [mappedPath()],
    projector: { inverse: ([x, z]) => [x, z] },
    geojson: { name: "Whole Park Detector Fixture" }
  };
}

function imageryFixture() {
  const inside = (x, z, minX, minZ, maxX, maxZ) => x >= minX && x <= maxX && z >= minZ && z <= maxZ;
  return {
    status: "available",
    mode: "evidence",
    provenanceComplete: true,
    minimumGsdM: 0.25,
    source: { provider: "Synthetic fixture", sourceUrl: "https://example.test", license: "CC0-1.0", capturedAt: "2026-07-01" },
    rasters: [{ sha256: "fixture", resolutionM: 0.25 }],
    sampleRgbLocal(x, z) {
      const mapped = x >= 5 && x <= 35 && Math.abs(z - 40) <= 3;
      const nearPlaza = inside(x, z, 45, 34, 61, 50);
      const distantYard = inside(x, z, 80, 5, 96, 21);
      return mapped || nearPlaza || distantYard ? [60, 62, 64] : [70, 150, 58];
    }
  };
}

test("whole-park discovery compiles a high-confidence nearby unmapped plaza and rejects a distant yard", () => {
  const map = mapFixture();
  const sources = {
    orthophoto: imageryFixture(),
    elevation: { provider: "none", points: [] }
  };
  const result = recoverPathTopology(map, sources, {
    pathDiscoveryMode: "evidence",
    pathDiscoveryScope: "whole-park",
    pathDiscoveryGridM: 1,
    pathDiscoveryMinAreaM2: 12,
    pathDiscoveryMinNovelAreaM2: 8,
    pathDiscoveryIndependentMinAreaM2: 28,
    pathDiscoveryIndependentPixelConfidence: 0.76,
    pathDiscoveryIndependentMinConfidence: 0.84,
    pathDiscoveryIndependentMaxAnchorDistanceM: 42,
    pathDiscoveryMinConfidence: 0.7
  });

  assert.equal(result.summary.scope, "whole-park");
  assert.ok(result.summary.independentCandidates >= 1);
  assert.ok(result.summary.independentAccepted >= 1);
  assert.ok(result.summary.independentCompiled >= 1);
  const discovered = map.features.filter((feature) => feature.tags?.["orthophoto:discovered"] === "yes");
  assert.equal(discovered.length, 1);
  assert.equal(discovered[0].tags["orthophoto:discovery_scope"], "independent-plaza");
  assert.ok(discovered[0].pathTopology.anchorDistanceM <= 42);
  assert.equal(discovered[0].pathTopology.shape.plazaLike, true);
  assert.equal(discovered[0].tags["surface:colour"], "#3c3e40");
});

test("connected scope preserves the original seeded-only behavior", () => {
  const map = mapFixture();
  const sources = { orthophoto: imageryFixture(), elevation: { provider: "none", points: [] } };
  const result = recoverPathTopology(map, sources, {
    pathDiscoveryMode: "evidence",
    pathDiscoveryScope: "connected",
    pathDiscoveryGridM: 1,
    pathDiscoveryMinConfidence: 0.7
  });
  assert.equal(result.summary.scope, "connected");
  assert.equal(result.summary.independentCompiled, 0);
  assert.equal(map.features.filter((feature) => feature.tags?.["orthophoto:discovered"] === "yes").length, 0);
});

import { parseArgs } from "../src/lib/args.mjs";

test("whole-park discovery CLI flags normalize and validate", () => {
  const parsed = parseArgs([
    "build",
    "--path-discovery-mode", "evidence",
    "--path-discovery-scope", "whole-park",
    "--path-discovery-independent-pixel-confidence", "0.79",
    "--path-discovery-independent-min-confidence", "0.87",
    "--path-discovery-independent-min-area-m2", "30",
    "--path-discovery-independent-max-anchor-distance-m", "45"
  ]);
  assert.equal(parsed.options.pathDiscoveryScope, "whole-park");
  assert.equal(parsed.options.pathDiscoveryIndependentPixelConfidence, 0.79);
  assert.equal(parsed.options.pathDiscoveryIndependentMinConfidence, 0.87);
  assert.equal(parsed.options.pathDiscoveryIndependentMinAreaM2, 30);
  assert.equal(parsed.options.pathDiscoveryIndependentMaxAnchorDistanceM, 45);
});

import { enrichUniversalFidelity } from "../src/lib/fidelity.mjs";
import { compileMap } from "../src/lib/raster.mjs";

test("recovered plaza paints its measured palette over natural ground without survey edging", () => {
  const map = mapFixture();
  const sources = {
    center: { lon: 0, lat: 0 },
    orthophoto: imageryFixture(),
    elevation: { provider: "none", points: [], minM: 0 }
  };
  recoverPathTopology(map, sources, {
    pathDiscoveryMode: "evidence",
    pathDiscoveryScope: "whole-park",
    pathDiscoveryGridM: 1,
    pathDiscoveryIndependentPixelConfidence: 0.76,
    pathDiscoveryIndependentMinConfidence: 0.84,
    pathDiscoveryIndependentMaxAnchorDistanceM: 42,
    pathDiscoveryMinConfidence: 0.7
  });
  enrichUniversalFidelity(map, sources, { accuracyMode: "plausible", pathEdgeMode: "off" });
  const discovered = map.features.find((feature) => feature.tags?.["orthophoto:discovered"] === "yes");
  assert.ok(discovered);
  assert.equal(discovered.surfaceStyle.colour, "#3c3e40");
  assert.equal(discovered.surfaceStyle.material, "asphalt");
  assert.equal(discovered.fidelity.path.edgeStyle, null);

  const compilation = compileMap({
    parkName: "Whole Park Detector Fixture",
    map,
    sources,
    accuracy: { score: 0.7, grade: "C", exact3d: false },
    options: {
      scale: 1,
      maxCells: 100_000,
      accuracyMode: "plausible",
      buildings: "markers",
      aerialTerrainMode: "off",
      pathEdgeMode: "off",
      noRideInfoSigns: true
    }
  });
  assert.ok(compilation.stats.pathPlazaCellsWritten > 100);
  assert.ok(compilation.stats.pathNaturalTopCellsReplaced > 100);
  assert.equal(compilation.meta.pathEdgeOutput.status, "no-explicit-edge-evidence");
  assert.ok(compilation.meta.surfaceStyles.some((style) => style.colour === "#3c3e40" && style.material === "asphalt"));
});
