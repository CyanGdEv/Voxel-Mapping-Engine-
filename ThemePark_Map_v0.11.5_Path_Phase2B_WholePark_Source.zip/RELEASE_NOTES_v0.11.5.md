# ThemePark Map v0.11.5 — Path Phase 2B

This release extends orthophoto path recovery beyond mapped-route expansion. High-confidence hardscape can now be detected as an independent plaza or route candidate when it is safely located near the guest path network.

## Whole-park discovery

Use:

```text
--path-discovery-mode evidence
--path-discovery-scope whole-park
```

The detector combines mapped-path appearance prototypes with a generic hardscape classifier. An independent component can compile only when all of the following hold:

- provenance-complete evidence-mode orthophoto;
- strong pixel and component confidence;
- no mapped building, water, or woody-vegetation overlap;
- plausible plaza compactness or route elongation;
- bounded distance to the guest path network;
- no steep-terrain or bridge-required rejection.

## Surface appearance

Each accepted component uses its own robust image colour and texture samples to select asphalt, concrete, paving-stone, or gravel palettes. The final Minecraft path still replaces only the top natural-ground layer and preserves the DTM elevation.

## QA

`path-topology-evidence.json` and `path-topology-qa.geojson` now include discovery class, anchor distance, independent-pixel fraction, shape metrics, colour, material, and compilation status.

## Safety defaults

- Independent pixel confidence: `0.78`
- Independent component confidence: `0.86`
- Independent minimum area: `28 m²`
- Maximum guest-network anchor distance: `42 m`

Connected mode remains available and retains the original route-seeded behavior.
