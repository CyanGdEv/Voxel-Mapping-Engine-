# ThemePark Map v0.11.6 — Automatic Aerial Acquisition Phase 2C

## Delivered

- Automatic Environment Agency vertical-aerial coverage discovery.
- Automatic OpenAerialMap search and rights-filtered direct raster acquisition.
- Manual orthophoto remains a supported final source.
- `--path-source aerial-required` fail-closes instead of silently creating an OSM-only benchmark.
- Park-wide RGB coverage estimation with a default 95% benchmark gate.
- Whole-park detector execution and independent-candidate gates.
- Source acquisition audit written to `source-acquisition.json`.

## Provider behavior

Environment Agency coverage is ranked by ground resolution and capture date. Direct raster URLs are downloaded only when the catalogue exposes a usable GeoTIFF/ECW URL. Coverage-only records are never misrepresented as imagery. OpenAerialMap records require a supported open licence and direct raster URL.

## Benchmark guarantees

An aerial-required build fails when imagery is missing, below the coverage threshold, path discovery is disabled, no hardscape component is analyzed, or no independent whole-park candidate is found.
