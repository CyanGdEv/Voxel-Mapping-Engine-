import assert from "node:assert/strict";
import test from "node:test";
import { enforceAerialBenchmark } from "../src/lib/aerial-benchmark.mjs";

const validSources = { orthophoto: { status: "available", coverage: 0.98 } };
const validTopology = { mode: "evidence", scope: "whole-park", grid: { candidatePixels: 25 }, connectedComponents: 2, independentCandidates: 1 };

test("mapped-only builds bypass the aerial benchmark gate", () => {
  assert.equal(enforceAerialBenchmark({ sources: {}, pathTopology: {}, options: {} }).status, "not-required");
});

test("aerial-required rejects missing imagery and low coverage", () => {
  assert.throws(() => enforceAerialBenchmark({ sources: { orthophoto: { status: "not-supplied" } }, pathTopology: {}, options: { pathSource: "aerial-required" } }), /requires a usable orthophoto/);
  assert.throws(() => enforceAerialBenchmark({ sources: { orthophoto: { status: "available", coverage: 0.8 } }, pathTopology: validTopology, options: { pathSource: "aerial-required", orthophotoMinCoverage: 0.95 } }), /below 95.0%/);
});

test("aerial-required refuses an unchanged detector result", () => {
  assert.throws(() => enforceAerialBenchmark({ sources: validSources, pathTopology: { ...validTopology, grid: { candidatePixels: 0 }, connectedComponents: 0 }, options: { pathSource: "aerial-required" } }), /no analyzable hardscape/);
  assert.throws(() => enforceAerialBenchmark({ sources: validSources, pathTopology: { ...validTopology, independentCandidates: 0 }, options: { pathSource: "aerial-required" } }), /independent candidates/);
});

test("aerial-required passes a meaningful whole-park analysis", () => {
  const result = enforceAerialBenchmark({ sources: validSources, pathTopology: validTopology, options: { pathSource: "aerial-required" } });
  assert.equal(result.status, "passed");
  assert.equal(result.coverage, 0.98);
});
