import assert from "node:assert/strict";
import test from "node:test";
import { parseArgs } from "../src/lib/args.mjs";

test("automatic aerial and fail-closed flags normalize", () => {
  const { options } = parseArgs(["build", "--path-source", "aerial-required", "--source-profile", "open", "--source-failure-mode", "continue", "--orthophoto-min-coverage", "0.95", "--aerial-benchmark-min-independent-candidates", "1"]);
  assert.equal(options.pathSource, "aerial-required");
  assert.equal(options.sourceProfile, "open");
  assert.equal(options.orthophotoMinCoverage, 0.95);
  assert.equal(options.aerialBenchmarkMinIndependentCandidates, 1);
});
