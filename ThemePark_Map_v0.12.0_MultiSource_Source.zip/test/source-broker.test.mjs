import assert from "node:assert/strict";
import { gzipSync } from "node:zlib";
import { createServer } from "node:http";
import { chmod, mkdtemp, readFile, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import {
  acquireAutomaticSources,
  bboxQuadkeys,
  isOpenLicense,
  lonLatToTile,
  parseCsv,
  tileXYToQuadKey
} from "../src/lib/source-broker.mjs";

const CHESSINGTON_BBOX = { south: 51.3458, west: -0.3228, north: 51.3535, east: -0.3133 };

test("quadkeys and CSV parsing are deterministic", () => {
  assert.deepEqual(lonLatToTile(0, 0, 1), { x: 1, y: 1 });
  assert.equal(tileXYToQuadKey(3, 5, 3), "213");
  assert.ok(bboxQuadkeys(CHESSINGTON_BBOX, 9).length >= 1);
  assert.deepEqual(parseCsv('QuadKey,Url,Note\n031313131,"https://example.test/a,b.gz","A ""quoted"" note"\n'), [{
    quadkey: "031313131",
    url: "https://example.test/a,b.gz",
    note: 'A "quoted" note'
  }]);
});

test("imagery licence gate rejects non-commercial and ambiguous records", () => {
  assert.equal(isOpenLicense("CC-BY-4.0"), true);
  assert.equal(isOpenLicense("https://creativecommons.org/licenses/by/4.0/"), true);
  assert.equal(isOpenLicense("https://creativecommons.org/licenses/by-sa/4.0/"), true);
  assert.equal(isOpenLicense("OGL-3.0"), true);
  assert.equal(isOpenLicense("CC-BY-NC-4.0"), false);
  assert.equal(isOpenLicense("CC-BY-ND-4.0"), false);
  assert.equal(isOpenLicense("All rights reserved"), false);
  assert.equal(isOpenLicense(""), false);
});

test("broker stages Microsoft footprints and only eligible OpenAerialMap imagery", async (t) => {
  const cacheDir = await mkdtemp(path.join(os.tmpdir(), "tpmap-source-broker-"));
  const quadkey = bboxQuadkeys(CHESSINGTON_BBOX, 9)[0];
  const inside = {
    type: "Feature",
    properties: { height: 12.5 },
    geometry: { type: "Polygon", coordinates: [[
      [-0.3200, 51.3480], [-0.3198, 51.3480], [-0.3198, 51.3482], [-0.3200, 51.3482], [-0.3200, 51.3480]
    ]] }
  };
  const outside = {
    type: "Feature",
    properties: {},
    geometry: { type: "Polygon", coordinates: [[[1, 1], [1.1, 1], [1.1, 1.1], [1, 1.1], [1, 1]]] }
  };
  const tileBody = gzipSync(`${JSON.stringify(inside)}\n${JSON.stringify(outside)}\n`);
  let baseUrl = "";
  const server = createServer((request, response) => {
    const url = new URL(request.url, baseUrl);
    if (url.pathname === "/index.csv") {
      response.setHeader("content-type", "text/csv");
      response.end(`QuadKey,Url\n${quadkey},${baseUrl}/tile.geojsonl.gz\n`);
      return;
    }
    if (url.pathname === "/tile.geojsonl.gz") {
      response.setHeader("content-type", "application/gzip");
      response.end(tileBody);
      return;
    }
    if (url.pathname === "/FeatureServer/10/query") {
      response.setHeader("content-type", "application/json");
      response.end(JSON.stringify({
        type: "FeatureCollection",
        features: [{
          type: "Feature", id: 10,
          properties: { FILENAME: "TQ16_2024_10CM.ecw", YEAR: 2024, RESOLUTION: 0.1, BANDS: 4, SD_FLOWN: "2024-05-01", ED_FLOWN: "2024-05-02" },
          geometry: inside.geometry
        }]
      }));
      return;
    }
    if (url.pathname === "/meta") {
      response.setHeader("content-type", "application/json");
      response.end(JSON.stringify([
        {
          _id: "restricted",
          uuid: `${baseUrl}/restricted.tif`,
          gsd: 0.05,
          acquisition_end: "2026-01-01",
          properties: { license: "CC-BY-NC-4.0" }
        },
        {
          _id: "eligible",
          uuid: `${baseUrl}/eligible.tif`,
          gsd: 0.1,
          acquisition_end: "2025-06-01",
          provider: "Fixture Aerial",
          properties: { license: "CC-BY-4.0" }
        }
      ]));
      return;
    }
    if (url.pathname === "/eligible.tif") {
      response.setHeader("content-type", "image/tiff");
      response.end(Buffer.from("II*\u0000fixture-geotiff-placeholder"));
      return;
    }
    response.statusCode = 404;
    response.end("not found");
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  baseUrl = `http://127.0.0.1:${server.address().port}`;

  const options = {
    sourceProfile: "open",
    sourceFailureMode: "fail",
    noAutoOverture: true,
    eaAerialIndexUrl: `${baseUrl}/FeatureServer/10/query`,
    microsoftBuildingsIndexUrl: `${baseUrl}/index.csv`,
    openAerialMapUrl: `${baseUrl}/meta`,
    autoSourceTimeoutMs: 5_000,
    autoSourceMaxMb: 10,
    orthophotoMaxGsdM: 1,
    overture: [],
    publicData: [],
    orthophoto: []
  };
  const summary = await acquireAutomaticSources(options, {
    bbox: CHESSINGTON_BBOX,
    cacheDir,
    userAgent: "ThemeParkMap-test/0.12.0"
  });

  assert.equal(summary.status, "available");
  assert.equal(summary.providers["microsoft-buildings"].acceptedFeatures, 1);
  assert.equal(summary.providers["ea-aerial-index"].status, "coverage-only");
  assert.equal(summary.providers["ea-aerial-index"].bestCandidate.resolutionM, 0.1);
  assert.equal(summary.providers.openaerialmap.selected.id, "eligible");
  assert.equal(options.publicData.length, 1);
  assert.equal(options.orthophoto.length, 1);
  const geojson = JSON.parse(await readFile(options.publicData[0], "utf8"));
  assert.equal(geojson.features.length, 1);
  assert.equal(geojson.features[0].properties.kind, "building");
  assert.equal(geojson.source.license, "CDLA-Permissive-2.0");
});

test("broker invokes an overturemaps-compatible command per requested type", async () => {
  const cacheDir = await mkdtemp(path.join(os.tmpdir(), "tpmap-overture-broker-"));
  const command = path.join(cacheDir, "fake-overture.sh");
  await writeFile(command, `#!/bin/sh\nout=""\nprev=""\nfor arg in "$@"; do\n  if [ "$prev" = "-o" ]; then out="$arg"; fi\n  prev="$arg"\ndone\nprintf '{"type":"FeatureCollection","features":[]}\\n' > "$out"\n`);
  await chmod(command, 0o755);
  const options = {
    sourceProfile: "open",
    sourceFailureMode: "fail",
    overtureCommand: command,
    overtureTypes: "building,water",
    noAutoMicrosoftBuildings: true,
    noAutoEaAerial: true,
    noAutoOpenAerialMap: true,
    autoSourceTimeoutMs: 5_000,
    overture: [], publicData: [], orthophoto: []
  };
  const summary = await acquireAutomaticSources(options, {
    bbox: CHESSINGTON_BBOX,
    cacheDir,
    userAgent: "ThemeParkMap-test/0.12.0"
  });
  assert.equal(summary.providers.overture.successfulTypes, 2);
  assert.equal(options.overture.length, 2);
});

test("fail mode records a cache audit before aborting", async () => {
  const cacheDir = await mkdtemp(path.join(os.tmpdir(), "tpmap-source-fail-"));
  const options = {
    sourceProfile: "open",
    sourceFailureMode: "fail",
    overtureCommand: "/bin/false",
    overtureTypes: "building",
    noAutoMicrosoftBuildings: true,
    noAutoEaAerial: true,
    noAutoOpenAerialMap: true,
    autoSourceTimeoutMs: 5_000,
    overture: [], publicData: [], orthophoto: []
  };
  await assert.rejects(
    acquireAutomaticSources(options, {
      bbox: CHESSINGTON_BBOX,
      cacheDir,
      userAgent: "ThemeParkMap-test/0.12.0"
    }),
    /Automatic source acquisition failed/
  );
  const audit = JSON.parse(await readFile(path.join(cacheDir, "automatic-sources", "source-acquisition.json"), "utf8"));
  assert.equal(audit.status, "failed");
  assert.equal(audit.providers.overture.status, "failed");
});
