#!/usr/bin/env node
import process from "node:process";
import { buildPark } from "../src/lib/pipeline.mjs";

const contact = process.env.TPMAP_CONTACT;
if (!contact) {
  console.error("Set TPMAP_CONTACT to a project URL or email before using live public services.");
  process.exit(2);
}

const result = await buildPark({
  parkName: "Chessington World of Adventures",
  bbox: "51.3458,-0.3228,51.3535,-0.3133",
  contact,
  acceptNominatimPolicy: true,
  sourceProfile: "open",
  sourceFailureMode: process.env.TPMAP_SOURCE_FAILURE_MODE || "continue",
  overtureTypes: "building,segment,infrastructure,land,land_cover,water,place",
  elevation: "ea-lidar",
  orthophotoMode: "evidence",
  pathDiscoveryMode: "evidence",
  pathTerrainMode: "conform",
  terrainDetailMode: "evidence",
  buildings: "shells",
  rideProfileMode: "auto",
  rideTerrainMode: "inferred",
  accuracyMode: "verified",
  palette: "realistic",
  out: process.env.TPMAP_OUT || "out/chessington-multisource"
}, (message) => console.error(`• ${message}`));

console.log(JSON.stringify(result, null, 2));
