# ThemePark Map v0.12.0 — automatic multi-source acquisition

This release changes the generator from a mostly manual non-OSM fusion workflow into an automatic bounded source-staging pipeline. A build can now request every credential-free provider adapter with `--source-profile open`.

## Implemented providers

- **Overture Maps:** invokes the official bbox downloader and stages each requested theme as local GeoJSON.
- **Microsoft Global ML Building Footprints:** selects the relevant level-9 tiles, streams compressed GeoJSONL, clips features to the park bounds, and emits a provenance-complete public-data file.
- **Environment Agency vertical aerial:** records matching survey coverage, resolution/date metadata, and download limitations. Coverage is not misrepresented as imagery.
- **OpenAerialMap:** ranks bounded imagery by GSD and date and downloads a direct raster only when the record supplies a supported open licence.

## Evidence and failure handling

Every provider writes status, source URL, licence, generated files, and limitations to `source-acquisition.json`. `--source-failure-mode continue` allows partial multi-source builds during provider outages; `fail` is suitable for release pipelines that require all planned sources.

Automatic sources use the existing conservative fusion rules. Overture cannot override matching OSM geometry, Microsoft footprints are treated as building candidates rather than survey truth, and imagery cannot affect blocks without the existing orthophoto evidence checks.

## Remaining limits

EA survey imagery packages still require an explicit download/export step from the public survey service. Full raw-LiDAR scene segmentation and independent coaster rail-pair reconstruction remain subsequent phases. Commercial sources such as OS NGD and Bluesky require credentials and written derivative-distribution terms before adapters can be enabled.
