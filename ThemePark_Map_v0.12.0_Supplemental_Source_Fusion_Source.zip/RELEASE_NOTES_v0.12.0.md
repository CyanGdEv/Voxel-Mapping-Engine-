# ThemePark Map v0.12.0 — Bounded Supplemental Source Fusion

This release adds a first-class supplemental data acquisition layer while preserving the compiler's evidence and licensing gates.

## Implemented sources

- National Trees Outside Woodland Map through bounded OGC API Features requests, automatic regional collection selection, canopy subtype and height preservation, and exact lone-tree canopy handling.
- Planning Data through bounded WGS84 polygon queries and pagination for recorded trees, Tree Preservation zones, ancient woodland, and listed buildings.
- Microsoft Global ML Building Footprints through level-9 quadkey selection, bounded partition downloads, bounded gzip GeoJSONL line streaming, confidence filtering, height preservation, and gap-fill-only fusion.
- OS OpenMap Local GeoJSON imports with Ordnance Survey provenance and gap-fill handling.
- Wikidata nearby georeferenced place metadata as CC0 semantic evidence.
- Wikimedia Commons nearby geotagged image, licence, author, date, and source evidence.
- OpenAerialMap catalogue discovery for imagery coverage, date, resolution, licence, and TMS candidates.
- Generic configured adapters for OGC API Features, ArcGIS FeatureServer layers, local GeoJSON, and remote GeoJSON.

## Safety and provenance

Every request is clipped to the requested park bounding box, paginated, cached, subject to feature and download limits, and represented in `supplemental-sources.json`. Optional source failures are fail-open by default and become explicit warnings; `--strict-supplemental-sources` changes them to build failures.

Microsoft and OS building/transportation sources are gap-fill only. Independent tree and planning observations remain separate evidence and never silently claim survey-grade accuracy.
